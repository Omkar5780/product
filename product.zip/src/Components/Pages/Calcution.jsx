import React from 'react'

function Calcution() {
  return (
    <>

    

  <input type="text" placeholder='enter product' />
  <input type="text" placeholder='enter product' />
  <input type="text" placeholder='enter product' />
  <input type="text" placeholder='enter product' />
    
    
    </>
  )
}

export default Calcution